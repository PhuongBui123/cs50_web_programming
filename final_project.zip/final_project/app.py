# import os
import re
from random import randrange

from cs50 import SQL
from flask import Flask, flash, jsonify, redirect, render_template, request, session, get_flashed_messages
from flask_session import Session
from tempfile import mkdtemp
from werkzeug.exceptions import default_exceptions, HTTPException, InternalServerError
# from werkzeug.security import check_password_hash, generate_password_hash

from helpers import apology, check, convert

# Configure application
app = Flask(__name__)

# # Create a temporary store
# store = dict()

# Ensure templates are auto-reloaded
app.config["TEMPLATES_AUTO_RELOAD"] = True

# Ensure responses aren't cached
@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response

# # Custom filter
# app.jinja_env.filters["usd"] = usd

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_FILE_DIR"] = mkdtemp()
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# pattern of a typical word
w_pattern = "(?!\s)(\w+)(((?!\s)(\W)?)\w+)?"

#--- Encode and Decode method ---#
def encode(inp, step, secret=None):
    if secret == None: 
        return convert(inp, step)
    else:
        store = []
        for match in re.finditer(w_pattern, inp):
            word = inp[match.start():match.end()]
            if word == secret:
                store.append(convert(word, step))
            else:
                store.append(word)
        return " ".join(store)

# to decode, the encoder must input their submitted step and encoded secret (not the submitted!)
def decode(inp, step, secret=None):
    return encode(inp, step*(-1), secret)
#-----------------------------#
    
# Configure CS50 Library to use SQLite database
## https://www.blog.pythonlibrary.org/2017/12/12/flask-101-adding-a-database/
###db = SQL(r"sqlite:///final_project.db", connect_args={'check_same_thread': False})

@app.route("/")
def index():
    # Clear working session whenever hit "refresh"
    session.clear()
    return render_template("home.html")

@app.route("/home", methods=["GET", "POST"])
def home():
    # Clear working session when clicking on Home
    session.clear()
    # Get link
    if request.method == 'GET':
        return redirect("/")
    else:
        method = request.form.get("method")
        if not method:
            return apology("must select a coding method")

        secret = request.form.get("secret")
        if not secret:
            secret = None
        
        inp = request.form.get("input")
        if not inp:
            return apology("must input your words in text box")
        text = check(inp)

        # Generate output
        if method == "encode":
            step = randrange(1, 200)
            output = encode(text, step, secret)
        else:
            step = request.form.get("step")
            if not step or step.isdigit() == False or int(step) <= 0:
                return apology("to DECODE, must pick a KEY")
            step = int(step)        
            output = decode(text, step, secret)
        
        # Return the final result
        return render_template("result.html", method=method, step=step, secret=secret, inp=text, output=output)

@app.route("/contact", methods=["GET", "POST"])
def contact():
    ''' Leave info if visitors would like to contact us'''
    # Clear working session when clicking on Home
    session.clear()
    # User reached route via GET (as by clicking a link or via redirect)
    if request.method == 'GET':
        # Contact info: Email, Phone number/Zalo/Viber, Skype
        pass
    else:
        # render_template("contact.html", .....)
        pass
    ## flashed message
    flash('Your information is recorded. We will reply soon!')
    return apology("ToDo")


def errorhandler(e):
    """Handle error"""
    if not isinstance(e, HTTPException):
        e = InternalServerError()
    return apology(e.name, e.code)

# Listen for errors
for code in default_exceptions:
    app.errorhandler(code)(errorhandler)