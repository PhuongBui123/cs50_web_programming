import re
from string import ascii_lowercase
from flask import redirect, render_template, request, session

# create alphabet dictionary
alpha_dict = dict(zip(list(range(0, 26)), list(ascii_lowercase)))
# assign {-1; " "} to avoid the overlap when adding "step"
alpha_dict[-1] = " "

def apology(message, code=400):
    """Render message as an apology to user."""
    def escape(s):
        """
        Escape special characters.

        https://github.com/jacebrowning/memegen#special-characters
        """
        for old, new in [("-", "--"), (" ", "-"), ("_", "__"), ("?", "~q"),
                         ("%", "~p"), ("#", "~h"), ("/", "~s"), ("\"", "''")]:
            s = s.replace(old, new)
        return s
    return render_template("apology.html", top=code, bottom=escape(message)), code

# pattern of a typical word
w_pattern = "(?!\s)(\w+)(((?!\s)(\W)?)\w+)?"

# Check number of words in the string
def check(inp):
    #num = sum(1 for i in re.finditer(w_pattern, inp))
    num, e = 0, 0
    for match in re.finditer(w_pattern, inp):
        # call the ending position of the ending letter of the word
        e = match.end()
        num += 1
        # Break at # words = 100, record the appropriate number of words to convert
        if num == 100: 
            break
    # Expected result        
    return inp[:e]

def convert(text, step):
        inp_data = [ord(c.lower()) - 97 for c in text]
        out_data = [-1 if i == -65 else i + step for i in inp_data]         
        output = ''.join(alpha_dict[j] if j == -1 else alpha_dict[j % 26] for j in out_data)
        return output