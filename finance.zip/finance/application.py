import os

from cs50 import SQL
from flask import Flask, flash, jsonify, redirect, render_template, request, session, get_flashed_messages
from flask_session import Session
from tempfile import mkdtemp
from werkzeug.exceptions import default_exceptions, HTTPException, InternalServerError
from werkzeug.security import check_password_hash, generate_password_hash

from helpers import apology, login_required, lookup, usd

# Configure application
app = Flask(__name__)

# Ensure templates are auto-reloaded
app.config["TEMPLATES_AUTO_RELOAD"] = True

# Ensure responses aren't cached
@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response

# Custom filter
app.jinja_env.filters["usd"] = usd

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_FILE_DIR"] = mkdtemp()
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Configure CS50 Library to use SQLite database
## https://www.blog.pythonlibrary.org/2017/12/12/flask-101-adding-a-database/
db = SQL(r"sqlite:///finance.db", connect_args={'check_same_thread': False})

# Make sure API key is set
if not os.environ.get("API_KEY"):
    raise RuntimeError("API_KEY not set")


@app.route("/")
# This part is called to keep flashing the session['user_id'] since login
@login_required
def index():
    # Update later!!!
    """Show portfolio of stocks"""
    # User reached route via GET (as by clicking a link or via redirect)
    if request.method == 'GET':
        # Query data from "history" table
        rows = db.execute("SELECT symbol, name, SUM(shares) AS shares FROM history WHERE user_id = :user_id GROUP BY symbol, name HAVING SUM(shares) > 0",
                            user_id=session["user_id"])

        # Current stock's information
        store_total = list()
        for row in rows:
            row["current_price"] = lookup(row["symbol"])['price']
            row["price_shown"] = usd(row["current_price"])
            row["total"] = row["current_price"] * row["shares"]
            row["total_shown"] = usd(row["total"])
            store_total.append(row["total"])
        ## checking
        print("current value of stocks", sum(store_total))

        # Query current cash balance
        cash = db.execute("SELECT cash FROM users WHERE id = :user_id", user_id=session["user_id"])
        cash_balance = cash[0]["cash"]
        # Calculate grand total of portfolio
        grand_total = cash_balance + sum(store_total)

        # Return history page
        return render_template("portfolio.html", rows=rows, cash_balance=usd(cash_balance), grand_total=usd(grand_total))


@app.route("/buy", methods=["GET", "POST"])
@login_required
def buy():
    """Buy shares of stock"""
    # User reached route via GET (as by clicking a link or via redirect)
    if request.method == 'GET':
        return render_template("buy.html")
    # User reached route via POST (as by submitting a form via POST)
    else:
        # Ensure valid symbol is submitted
        tmp = request.form.get("symbol")
        if not lookup(tmp):
            return apology("must provide a valid symbol", 403)
        
        # Ensure share(s) are submitted and positive integer
        shares = request.form.get("shares")
        if not shares or int(shares) < 1 or shares.isdigit() == False:
            return apology("must provide a positive integer", 403)
        shares = int(shares)

        # Assign symbol to expected variable
        symbol = lookup(tmp)['symbol']
        name = lookup(tmp)['name']
        # Look up stock's current price
        ## lookup(tmp)['price'] is already converted to float in helpers.py
        price = lookup(tmp)['price']
        total = price * shares

        # Check the amount of current cash balance and total purchase's value
        ## Since we still keep the session of userid when login, we can reuse it
        rows = db.execute("SELECT cash FROM users WHERE id = :user_id", user_id=session["user_id"])
        # rows[-1] to extract the lastest updated data
        cash_balance = rows[-1]['cash']

        if total > cash_balance:
            return apology("purchase's value exceed cash balance!", 403)

        # If "buy" table does not exist, create a new one in finance.db to record data
        ## Insert a new row of data whenever a purchase transaction is undertaken
        db.execute("INSERT INTO history(user_id, symbol, name, shares, price, total) VALUES(:user_id, :symbol, :name, :shares, :price, :total)",
                    user_id=session["user_id"],
                    symbol=symbol,
                    name=name,
                    shares=shares,
                    price=usd(price),
                    total=total
                    )

        # Update cash balance in "users" table
        cash = db.execute("SELECT cash FROM users WHERE id = :user_id", user_id=session["user_id"])
        cash_balance = cash[0]["cash"] + total * (-1)
        db.execute("UPDATE users SET cash = :cash_balance WHERE id = :user_id",
                    cash_balance=cash_balance,
                    user_id=session["user_id"]
                    )

        # Go to index page
        ## Input flashed message
        flash('Bought!')
        return redirect("/")

@app.route("/history")
@login_required
def history():
    """Show history of transactions"""
    # User reached route via GET (as by clicking a link or via redirect)
    if request.method == 'GET':

        # Query data from "history" table
        rows = db.execute("SELECT * FROM history WHERE user_id = :user_id",
                            user_id=session["user_id"]
                            )

        # Return history page
        return render_template("history.html", rows=rows)


@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in"""

    # Forget any user_id
    session.clear()

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 403)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 403)

        username = request.form.get("username")
        # Query database for username
        rows = db.execute("SELECT * FROM users WHERE username = :username",
                          username=username)

        # Ensure username exists and password is correct
        if len(rows) != 1 or not check_password_hash(rows[0]["hash"], request.form.get("password")):
            return apology("invalid username and/or password", 403)

        # Remember which user has logged in
        session["user_id"] = rows[0]["id"]

        # Redirect user to home page
        return redirect("/")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("login.html")


@app.route("/logout")
def logout():
    """Log user out"""

    # Forget any user_id
    session.clear()

    # Redirect user to login form
    return redirect("/")


@app.route("/quote", methods=["GET", "POST"])
@login_required
def quote():
    """Get stock quote."""
    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        tmp = request.form.get("symbol")
        # Ensure username was submitted
        if not tmp:
            return apology("must provide symbol", 403)

        # Ensure valid symbol was submitted
        if not lookup(tmp):
            return apology("must provide a valid symbol", 403)
        # If inputted symbol is valid, assign to expected variables
        symbol = lookup(tmp)["symbol"]
        price = lookup(tmp)["price"]
        name = lookup(tmp)["name"]

        # Go to quoted page
        return render_template("quoted.html", symbol=symbol, name=name, price=usd(price))

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("quote.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    """Register user"""
    # Forget any user_id
    session.clear()

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        confirmation = request.form.get("confirmation")
        pass_hashed = generate_password_hash(confirmation)

        # Ensure username was submitted
        if not username:
            return apology("must provide username", 403)
        # Ensure password was submitted
        elif not password:
            return apology("must provide password", 403)
        # Ensure password was submitted
        elif not confirmation:
            return apology("must provide confirmation", 403)
        # Ensure password and confirmation are matched
        elif password != confirmation:
            return apology("password and confirmation are not matched", 403)

        # Query database for username to check the existence of username
        rows = db.execute("SELECT * FROM users WHERE username = :username",
                          username=request.form.get("username"))
        ## If username exists, send apology
        if len(rows) >= 1:
            return apology("username exists!", 403)

        # if that is a new username, insert into database
        db.execute("INSERT INTO users(username, hash) VALUES(:username, :pass_hashed)",
                          username=username,
                          pass_hashed=pass_hashed
                )

        # Remember which user has logged in
        rows = db.execute("SELECT * FROM users WHERE username = :username",
                          username=request.form.get("username"))
        session["user_id"] = rows[0]["id"]

        # Return to login page
        ## Input flashed message
        flash('Registered!')
        return redirect("/")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("register.html")


@app.route("/sell", methods=["GET", "POST"])
@login_required
def sell():
    """Sell shares of stock"""
    # User reached route via GET (as by clicking a link or via redirect)
    if request.method == 'GET':
        rows = db.execute("SELECT DISTINCT symbol FROM history WHERE user_id = :user_id", user_id=session["user_id"])
        print(rows)
        return render_template("sell.html", rows=rows)
    # User reached route via POST (as by submitting a form via POST)
    else:
        # Ensure valid symbol is submitted
        tmp = request.form.get("symbol")
        shares = request.form.get("shares")
        ##
        if not lookup(tmp):
            return apology("must provide a valid symbol", 403)
            
        # Ensure share(s) are submitted and positive integer
        if not shares or shares.isdigit() == False:
            return apology("must provide a positive integer", 403)
        ## multiply by -1 for selling
        shares = int(shares)*(-1)

        # Assign symbol to expected variable
        symbol = lookup(tmp)['symbol']
        name = lookup(tmp)['name']
        # Look up stock's current price
        ## lookup(tmp)['price'] is already converted to float in helpers.py
        price = lookup(tmp)['price']
        total = price * shares

        # Check number of available purchased shares of that stock
        ## Since we still keep the session of userid when login, we can reuse it
        rows = db.execute("SELECT SUM(shares) AS 'total_shares' FROM history WHERE user_id = :user_id AND symbol = :symbol GROUP BY user_id, symbol",
                            user_id=session["user_id"], symbol=symbol)
        # rows[-1] to extract the lastest updated data
        shares_balance = rows[0]['total_shares']

        if shares_balance < (shares*(-1)):
            flash("Exceed your shares balance!")
            return redirect("/")

         ## Insert a new row of data whenever a transaction is undertaken
        db.execute("INSERT INTO history(user_id, symbol, name, shares, price, total) VALUES(:user_id, :symbol, :name, :shares, :price, :total)",
                    user_id=session["user_id"],
                    symbol=symbol,
                    name=name,
                    shares=shares,
                    price=usd(price),
                    total=total
                    )

        # Update cash balance in "users" table
        cash = db.execute("SELECT cash FROM users WHERE id = :user_id", user_id=session["user_id"])
        cash_balance = cash[0]["cash"] + total * (-1)
        db.execute("UPDATE users SET cash = :cash_balance WHERE id = :user_id",
                    cash_balance=cash_balance,
                    user_id=session["user_id"]
                    )

        # Go to index page
        ## Input flashed message
        flash('Sold!')
        return redirect("/")


def errorhandler(e):
    """Handle error"""
    if not isinstance(e, HTTPException):
        e = InternalServerError()
    return apology(e.name, e.code)


# Listen for errors
for code in default_exceptions:
    app.errorhandler(code)(errorhandler)
