function greet()
{
    var name = document.querySelector("#name").value;
    if (name === "")
    {
        alert("Hi, Joker. I know you have not left your name.");
    }
    else
    {
        alert("Hi " + name + ". Welcome!");
    }
}

function email()
{
    var email = document.querySelector("#emailAddress").value;
    var message = document.querySelector("#message").value;
    if (email === "")
    {
        email = "Joker";
        alert("C'mon, Joker. Input an email.");
    }
    else if (message === "")
    {
        alert("Cannot leave an empty message, " + email);
    }
    else
    {
        alert("Great! Your email and message have been recorded.\nPB will contact you shortly. Have a nice day!");
    }
}