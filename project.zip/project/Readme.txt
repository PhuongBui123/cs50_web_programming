Title: Send message in your own way!
Function 1: encode a series of text by applying cyphertext with different types of encoding.
Function 2: dencode a series of cyphertext with the decoding method provided from the econder (above).
Function 3: use RegEx to convert some selected texts into cyphertexts.

Work flow: Option 1 (all texts), Option 2 (selected texts).
Option 1:
+ Function 1: encode = input normal texts & encoding method -> processing -> cyphertexts.
+ Function 2: decode: input cyphertexts & decoding method -> processing -> normal texts (above).
Option 2:
+ Same as 2 above functions with applied RegEx.

Unique points of selling:
1. Multiple choice of encoding methods that are provided by the web-app creator.
2. "Recommend" page where users can input their own encoding method and explain how to decode it.
  2.1. Category 2 (out-of-scope methods): generate an automatic alert for the users and creator, 
				creator will collect to add up that encoding method mannually.
  2.2. Category 1 (simple methods): app will scan the readibilty of the encoding method,
				if possible, immediately generate the encoding method then apply on spot.

=====================================
Web pages:
Version 1: Limit 100 words per input.
1. Index (home/main page): 
    + Brief introductions
    + An instruction video. 
    + Input area: (1) Options to use, (2) Text input area (flash limit if exceed!), (3) Output area.
    + A "href" link to Feedback page. 
2. Feedback: contact + content of feedback -> on submit, generate a summary of submitted content.
3. Summary: summary of feedback.
